# BigGram X — black & white Android UI prototype

Android starter project using Kotlin + Jetpack Compose.

## Included prototype screens
- Black/white BigGram X interface.
- Chats, Calls, BigBen, Profile navigation.
- Call screen with UI toggles for microphone, speaker, Bluetooth audio, camera and screen-share.
- Demo `@admin` moderation screen.
- BigBen Stars, Premium and Business presentation.
- Launcher icon: black background with white X; launcher label is blank (some launchers may still show an app label).

## Important limitations
This is a **UI prototype**, not a production messenger. The call controls currently only change their visual state. They do not activate Bluetooth routing, camera capture, screen capture, or connect a real call. Real calls and screen sharing require a signaling backend and WebRTC integration, Android runtime permissions, foreground-service handling, and Android's MediaProjection consent flow. Messages, accounts, groups, Stars, subscriptions and moderation also need a secure backend.

## Build on GitHub from a phone
The `.github/workflows/android.yml` workflow builds a debug APK. Upload the *contents* of this project folder to the root of your GitHub repository (not the ZIP file itself), then open Actions and run `Build BigGram X APK`. Download the APK from the workflow Artifacts after a successful run.
