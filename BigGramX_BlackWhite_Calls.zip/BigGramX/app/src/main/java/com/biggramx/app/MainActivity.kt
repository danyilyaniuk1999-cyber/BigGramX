package com.biggramx.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050505)
private val Panel = Color(0xFF141414)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFF929292)
private val Accent = Color(0xFFBDBDBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BigGramApp() }
    }
}

@Composable
fun BigGramApp() {
    var tab by remember { mutableStateOf("Чаты") }
    var showAdmin by remember { mutableStateOf(false) }
    var showCall by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = White,
        onPrimary = Bg, onBackground = White, onSurface = White,
        secondary = Accent
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (showCall) {
                CallScreen(onEnd = { showCall = false })
            } else {
                Column {
                    Header()
                    when {
                        showAdmin -> AdminScreen(onBack = { showAdmin = false })
                        tab == "Чаты" -> ChatsScreen()
                        tab == "Звонки" -> CallsScreen(onCall = { showCall = true })
                        tab == "Профиль" -> ProfileScreen(onAdmin = { showAdmin = true })
                        else -> BigBenScreen()
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Color(0xFF0D0D0D)) {
                        listOf("Чаты", "Звонки", "BigBen", "Профиль").forEach { item ->
                            NavigationBarItem(
                                selected = tab == item && !showAdmin,
                                onClick = { tab = item; showAdmin = false },
                                icon = {
                                    Icon(when(item) {
                                        "Чаты" -> Icons.Default.ChatBubbleOutline
                                        "Звонки" -> Icons.Default.Call
                                        "BigBen" -> Icons.Default.Stars
                                        else -> Icons.Default.PersonOutline
                                    }, contentDescription = item)
                                },
                                label = { Text(item) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = White, selectedTextColor = White,
                                    indicatorColor = Color(0xFF303030),
                                    unselectedIconColor = Muted, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF090909))
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Color.White, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
            Text("X", color = Color.Black, fontSize = 25.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("BigGram X", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = White)
            Text("MESSAGES • CALLS • COMMUNITY", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.Search, null, tint = White, modifier = Modifier.size(25.dp))
    }
}

data class Chat(val name: String, val handle: String, val message: String, val time: String, val symbol: String)

@Composable
fun ChatsScreen() {
    val chats = listOf(
        Chat("BigGram X News", "@biggramx", "Добро пожаловать в BigGram X", "12:40", "X"),
        Chat("Избранное", "Личное пространство", "Сохраняйте важные сообщения", "Вчера", "★"),
        Chat("BigBen Community", "@bigben", "Обсуждение сообщества", "Пн", "B")
    )
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Сообщения", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("Все ваши разговоры", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(chats) { chat ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(17.dp))
                        .clickable { }.padding(14.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(51.dp).background(Color(0xFF292929), CircleShape), contentAlignment = Alignment.Center) {
                        Text(chat.symbol, color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.name, fontWeight = FontWeight.SemiBold)
                        Text(chat.message, color = Muted, fontSize = 13.sp, maxLines = 1)
                    }
                    Text(chat.time, color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun CallsScreen(onCall: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Звонки", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("Голосовые и видеозвонки", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFF303030), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Call, null, tint = White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Тестовый звонок", fontWeight = FontWeight.SemiBold)
                Text("Проверка интерфейса звонка", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onCall) { Icon(Icons.Default.Call, null, tint = White) }
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onCall, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Bg)) {
            Icon(Icons.Default.VideoCall, null)
            Spacer(Modifier.width(8.dp))
            Text("Открыть экран звонка")
        }
        Text("Пока это демонстрационный экран. Для настоящих звонков нужен сервер сигнализации и WebRTC.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp))
    }
}

@Composable
fun CallScreen(onEnd: () -> Unit) {
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    var bluetooth by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf(false) }
    var screenShare by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("BIGGRAM X CALL", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(112.dp).background(Color(0xFF242424), CircleShape), contentAlignment = Alignment.Center) {
            Text("X", color = White, fontSize = 54.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(22.dp))
        Text("BigGram X", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Соединение не установлено • демо-режим", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CallToggle(Icons.Default.MicOff, "Микрофон", muted) { muted = !muted }
            CallToggle(Icons.Default.VolumeUp, "Динамик", speaker) { speaker = !speaker }
            CallToggle(Icons.Default.Bluetooth, "Bluetooth", bluetooth) { bluetooth = !bluetooth }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CallToggle(Icons.Default.Videocam, "Камера", camera) { camera = !camera }
            CallToggle(Icons.Default.ScreenShare, "Экран", screenShare) { screenShare = !screenShare }
        }
        Spacer(Modifier.height(30.dp))
        Button(
            onClick = onEnd,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935), contentColor = White)
        ) {
            Icon(Icons.Default.CallEnd, null)
            Spacer(Modifier.width(10.dp))
            Text("Завершить звонок", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text("Переключатели пока демонстрационные", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun CallToggle(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(92.dp)) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = if (active) Color.White else Color(0xFF262626),
            modifier = Modifier.size(62.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = if (active) Color.Black else White, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = if (active) White else Muted, fontSize = 12.sp)
    }
}

@Composable
fun ProfileScreen(onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(90.dp).background(Color(0xFF292929), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = White, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Мой профиль", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("@your_username", color = Muted)
        Spacer(Modifier.height(22.dp))
        InfoCard("BigBen Stars", "1 000 000 ★", Icons.Default.Stars)
        InfoCard("BigBen Premium", "Демонстрационный статус", Icons.Default.Star)
        InfoCard("BigBen Business", "Инструменты для бизнеса", Icons.Default.Business)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onAdmin, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Bg)) {
            Icon(Icons.Default.AdminPanelSettings, null)
            Spacer(Modifier.width(8.dp))
            Text("Панель @admin (демо)")
        }
        Text("Баланс и статусы демонстрационные", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun InfoCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(15.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = White)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun BigBenScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("BigBen", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("Возможности аккаунта", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        InfoCard("BigBen Stars", "Виртуальные звёзды и подарки", Icons.Default.Stars)
        InfoCard("BigBen Premium", "Расширенные возможности", Icons.Default.Star)
        InfoCard("BigBen Business", "Инструменты для компаний", Icons.Default.Business)
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) {
    var query by remember { mutableStateOf("@username") }
    var blocked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("@admin", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("DEMO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text("Модерация пользователей", color = Muted, modifier = Modifier.padding(bottom = 18.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Поиск по @username") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (blocked) "Удалённый аккаунт" else "Пользователь", fontWeight = FontWeight.Bold)
                Text(if (blocked) "Номер неизвестен • был в сети давно" else query, color = Muted, fontSize = 12.sp)
            }
            Switch(checked = blocked, onCheckedChange = { blocked = it })
        }
        Text("Это демонстрация интерфейса. Реальная блокировка требует серверной проверки и журнала действий.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}
